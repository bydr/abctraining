
<?php require_once('head.php');
?>

<div class="container">
    <br>
    <h2>Страницы для теста</h2>
    <ol>
        <li><a href="page_skillcharts.php">Skills chart (мужской) пустой</a></li>
        <li><a href="page_skillcharts_actives.php">Skills chart (мужской) пустой Активные поля</a></li>
        <li><a href="page_signin.php">Вход</a></li>
        <li><a href="page_training.php">Главная (стр. Тренировки)</a></li>
        <li><a href="page_training_empty.php">Главная (стр. Тренировки) Пустая</a></li>
        <li><a href="page_training_missed.php">Главная пропущена тренировка</a></li>
        <li><a href="page_training_done.php">Главная выполнена тренировка</a></li>
        <li><a href="page_task_done.php">стр. Задания выполнена</a></li>
        <li><a href="page_task.php">стр. Задания</a></li>
        <li><a href="page_testing_1.php">Тестирование. Шаг 1</a></li>
        <li><a href="page_testing_2.php">Тестирование. Шаг 2</a></li>
        <li><a href="page_testing_3.php">Тестирование. Шаг 3</a></li>
        <li><a href="page_testing_4.php">Тестирование. Шаг 4</a></li>
        <li><a href="page_testing_5.php">Тестирование. Шаг 5</a></li>
        <li><a href="page_testing_6.php">Тестирование. Шаг 6</a></li>
        <li><a href="page_testing_7.php">Тестирование. Шаг 7</a></li>
        <li><a href="page_testing_8.php">Тестирование. Шаг 8</a></li>
        <li><a href="page_testing_9.php">Тестирование. Шаг 9</a></li>
        <li><a href="page_testing_10.php">Тестирование. Шаг 10</a></li>
        <li><a href="page_testing_11.php">Тестирование. Шаг 11</a></li>
        <li><a href="page_testing_12.php">Тестирование. Шаг 12</a></li>
        <li><a href="page_testing_13.php">Тестирование. Шаг 13</a></li>
        <li><a href="page_testing_14.php">Тестирование. Шаг 14</a></li>
        <li><a href="page_testing_15.php">Тестирование. Шаг 15</a></li>
        <li><a href="page_testing_16.php">Тестирование. Шаг 16</a></li>
        <li><a href="page_testing_17.php">Тестирование. Шаг 17</a></li>
        <li><a href="page_testing_18.php">Тестирование. Шаг 18</a></li>
        <li><a href="page_testing_19.php">Тестирование. Шаг 19</a></li>
        <li><a href="page_schedule.php">Расписание</a></li>
        <li><a href="page_shedule_edit1.php">Расписание Изменение Шаг 1</a></li>
        <li><a href="page_shedule_edit2.php">Расписание Изменение Шаг 2</a></li>
    </ol>
</div>

<?php require_once('foot.php'); ?>
