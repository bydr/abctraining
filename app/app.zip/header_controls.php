<div class="header-controls">
    <button class="dr-btn dr-btn_box">
        <svg class="dr-icon">
            <use href="img/_src/sprite.svg#coin"></use>
        </svg>
    </button>
    <button class="dr-btn dr-btn_box">
        <svg class="dr-icon">
            <use href="img/_src/sprite.svg#faq"></use>
        </svg>
    </button>
    <button class="dr-btn dr-btn_box">
        <svg class="dr-icon">
            <use href="img/_src/sprite.svg#setting"></use>
        </svg>
    </button>
</div>
